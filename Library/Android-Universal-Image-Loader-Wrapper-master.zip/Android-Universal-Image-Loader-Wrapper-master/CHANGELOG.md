Change Log
===

v1.0.0*(06.09.2013)*
---
 * Introduced `ImageLoadingView` which is an ImageView that loads images

